.. Mbed TLS Versioned documentation master file, created by
   sphinx-quickstart on Thu Feb 23 18:13:44 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Mbed TLS API documentation
==========================

.. doxygenpage:: index
   :project: mbedtls-versioned

.. toctree::
   :caption: Contents
   :maxdepth: 1

   Home <self>
   api/grouplist.rst
   api/filelist.rst
   api/structlist.rst
   api/unionlist.rst
